﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.word = New System.Windows.Forms.Button()
        Me.ppt = New System.Windows.Forms.Button()
        Me.calc = New System.Windows.Forms.Button()
        Me.crash = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'word
        '
        Me.word.BackColor = System.Drawing.Color.Blue
        Me.word.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.word.ForeColor = System.Drawing.Color.White
        Me.word.Location = New System.Drawing.Point(12, 12)
        Me.word.Name = "word"
        Me.word.Size = New System.Drawing.Size(102, 89)
        Me.word.TabIndex = 0
        Me.word.Text = "word"
        Me.word.UseVisualStyleBackColor = False
        '
        'ppt
        '
        Me.ppt.BackColor = System.Drawing.Color.Red
        Me.ppt.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ppt.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ppt.ForeColor = System.Drawing.Color.White
        Me.ppt.Location = New System.Drawing.Point(145, 12)
        Me.ppt.Name = "ppt"
        Me.ppt.Size = New System.Drawing.Size(102, 89)
        Me.ppt.TabIndex = 1
        Me.ppt.Text = "powerpoint"
        Me.ppt.UseVisualStyleBackColor = False
        '
        'calc
        '
        Me.calc.BackColor = System.Drawing.Color.Cyan
        Me.calc.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.calc.Location = New System.Drawing.Point(289, 13)
        Me.calc.Name = "calc"
        Me.calc.Size = New System.Drawing.Size(111, 89)
        Me.calc.TabIndex = 2
        Me.calc.Text = "calculator"
        Me.calc.UseVisualStyleBackColor = False
        '
        'crash
        '
        Me.crash.BackColor = System.Drawing.Color.SandyBrown
        Me.crash.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.crash.Location = New System.Drawing.Point(12, 111)
        Me.crash.Name = "crash"
        Me.crash.Size = New System.Drawing.Size(111, 89)
        Me.crash.TabIndex = 3
        Me.crash.Text = "crash"
        Me.crash.UseVisualStyleBackColor = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(412, 212)
        Me.Controls.Add(Me.crash)
        Me.Controls.Add(Me.calc)
        Me.Controls.Add(Me.ppt)
        Me.Controls.Add(Me.word)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents word As System.Windows.Forms.Button
    Friend WithEvents ppt As System.Windows.Forms.Button
    Friend WithEvents calc As System.Windows.Forms.Button
    Friend WithEvents crash As System.Windows.Forms.Button

End Class
