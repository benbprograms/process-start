﻿Public Class Form1

    Private Sub word_Click(sender As System.Object, e As System.EventArgs) Handles word.Click


        Process.Start("winword.exe")
    End Sub

    Private Sub ppt_Click(sender As System.Object, e As System.EventArgs) Handles ppt.Click
        Process.Start("powerpnt.exe")
    End Sub

    Private Sub calc_Click(sender As System.Object, e As System.EventArgs) Handles calc.Click
        Process.Start("calc.exe")
    End Sub

    Private Sub crash_Click(sender As System.Object, e As System.EventArgs) Handles crash.Click
        Dim ays As Integer
        ays = MsgBox("are you sure you want to do that?", 36, "are you sure")
        If ays = 6 Then
            Throw New Exception("you asked for it!")
        Else

        End If
    End Sub
End Class
